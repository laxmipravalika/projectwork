<html>
<head>
<style>
.s1
{
width:500;
height:500;
border-style:solid;
border-color:#99ffbb;
border-width:thick;
top:50px;
position:relative;
margin:100px;
padding:23spx;
}
div {
    
    width: 1000px;
    height:500px;
    border: 10px solid #99ffbb;
    padding: 25px;
    margin: 25px;
}
.s2
{
color:"#ff3399";
}
body
{
background-repeat:no-repeat;
background-size:cover;
}
</style>
</head>
<body background="index10.jpg" text="#ff6666">
<h1 class="s2"><center>EVENT DETAILS</center></h1>
<center>
<div>
<form name="f1" method="post">
<table>
<tr>
<td>EVENT ID:</td>
<td><input type="text" name="t1"></td><br>
</tr>
<tr>
<td>EVENT NAME:</td>
<td><input type="text" name="t2"></td><br>
</tr>
<tr>
<td>EVENT DATE:</td>
<td><input type="text" name="t3"></td><br>
</tr>
<tr>
<td>NUMBER OF PARTICIPANTS:</td>
<td><input type="text" name="t4"></td><br>
</tr>
<tr>
<td>FIRST WINNER:</td>
<td><input type="text" name="t5"></td><br>
</tr>
<tr>
<td>SECOND WINNER:</td>
<td><input type="text" name="t6"></td><br>
</tr>
<tr>
<td>THIRD WINNER:</td>
<td><input type="text" name="t7"></td><br>
</tr><br>
<tr>
</tr><center>&nbsp&nbsp
<tr>
<td><input type="submit" name="b1" value="ADDEVENT" style="color:white;background-color:brown; height:30px" /></td>
</tr>
</center>
</table>
</form>
</div>
</center>
<?php
$eventid=$_POST['t1'];
$eventname=$_POST['t2'];
$eventdate=$_POST['t3'];
$numofparticipants=$_POST['t4'];
$firstwinner=$_POST['t5'];
$secondwinner=$_POST['t6'];
$thirdwinner=$_POST['t7'];
$conn=mysql_connect('localhost','root');
if(!$conn)
{
die('could not connect:'.mysql_errror());
}
mysql_select_db('project') or die(mysql_error());
$que="insert into debate(eventid,eventname,eventdate,numofparticipants,firstwinner,secondwinner,thirdwinner)values('$eventid','$eventname','$eventdate','$numofparticipants','$firstwinner','$secondwinner','$thirdwinner')";
$res=mysql_query($que,$conn) or die(mysql_error());
echo 'events are added successfully';
mysql_close($conn);
?>
</body>
</html>



