<html>
<head>
<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 16px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    cursor: pointer;
}
.button2 {
    background-color:#008CBA; 
    color: black; 
    border: 2px solid #008CBA;
}

.button2:hover {
    background-color: #008CBA;
    color: #008CBA;
}

.s1
{
background-image:url("sw.jpg");
color:#ccffcc;
height:50px;
border-style:solid;
border-color:#d24dff;
margin:10px;
padding:10px;
background-size:cover;
background-repeat:no-repeat;
}
.s2
{
background-image:url("index10.jpg");
height:520px;
border-style:solid;
border-color:#ff3377;
margin:10px;
padding:10px;
background-repeat:no-repeat;
background-size:cover;
}
</style>
</head>
<body bgcolor="black">
<center>
<h1 class="s1"><bold>WELCOME ADMIN!!</bold></h1>
<div class="s2">
<a href="addevent.php" class="button button2">ADD EVENT</a>
<a href="getevent.php"class="button button2">GET EVENT</a>
<a href="post.php"class="button button2">POST UPDATES</a>
<a href="delete.php"class="button button2">DELETE EVENT</a>
</div>
</center>
<?php
?>
</body>
</html>

