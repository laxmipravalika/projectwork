<?php

$con = mysql_connect("localhost","root","");

if (!$con)

{

die('Could not connect: ' . mysql_error());

}

mysql_select_db("mysql", $con);

$con = mysql_connect("localhost","root","");

if (!$con)

{

die('Could not connect: ' . mysql_error());

}

mysql_select_db("project", $con);

//$sql="select * from accountdtl";

$result = mysql_query("select * from debate where eventname='$_POST[name]'");

while($rowval = mysql_fetch_array($result))

 {

$eventid= $rowval['eventid'];

$eventname= $rowval['eventname'];

$eventdate= $rowval['eventdate'];

$numofparticipants= $rowval['numofparticipants'];

$firstwinner= $rowval['firstwinner'];

$secondwinner= $rowval['secondwinner'];

$thirdwinner= $rowval['thirdwinner'];
}

mysql_close($con);

 

?>

<html>
<head>
<style>
.s1
{
color:yellow;
height:50px;
border-style:solid;
border-color:#ff1a75;
border-width:thick;
margin:5px;
padding:5px;
background-repeat:no-repeat;
background-size:cover;
background-image:url(sw.jpg);
}
div {
    color:#008CBA;
    height:520px;
    border: 10px solid #ffff80;
    padding: 10px;
    margin: 10px;
background-repeat:no-repeat;
background-size:cover;
background-image:url("index10.jpg");
}
body
{
color:#008CBA;

}
</style>
</head>
<h1 class="s1"><center>EVENT DETAILS</center></h1>
<body  bgcolor="black">
<center>
<div>

<body>

<from >
<table>
 <tr>

            <td style="color:red;background-color:aqua;" class="auto-style3">EVENTID::</td>

            <td class="auto-style4">

                <input id="Text1" type="text" value='<?php echo  $eventid; ?>'/></td>

        </tr>

        <tr>

            <td style="color:red;background-color:aqua;" class="auto-style3">EVENTNAME</td>

            <td class="auto-style4">

                <input id="Text2" type="text" value='<?php echo  $eventname; ?>'/></td>

        </tr>

        <tr>

             <td style="color:red;background-color:aqua;" class="auto-style3">EVENTDATE</td>

            <td class="auto-style4">

                <input id="Text3" type="text" value='<?php echo  $eventdate; ?>' /></td>

        </tr>

        <tr>

             <td style="color:red;background-color:aqua;" class="auto-style3">NUMOFPARTICIPANTS</td>

            <td class="auto-style4">

                <input id="Text4" type="text" value='<?php echo  $numofparticipants; ?>' /></td>

        </tr>

        <tr>

            <td style="color:red;background-color:aqua;" class="auto-style3">FIRSTWINNER</td>

            <td class="auto-style4">

                <input id="Text5" type="text" value='<?php echo  $firstwinner; ?>' /></td>

        </tr>

        <tr>

           <td style="color:red;background-color:aqua;" class="auto-style3">SECONDWINNER</td>

            <td class="auto-style4">

                <input id="Text6" type="text" value='<?php echo  $secondwinner; ?>' ></td>

        </tr>

        <tr>

             <td style="color:red;background-color:aqua;" class="auto-style3">THIRDWINNER</td>

            <td class="auto-style4">

                <input id="Text7" type="text" value='<?php echo  $thirdwinner; ?>'/></td>

        </tr>

     <tr>

        <td></td>

        </tr>

    </table>

</form>
</div>
</center>
</body>

</html>