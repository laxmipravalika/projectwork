<html>
<head>
</head>
<?php
$name=$_POST['name'];
$pwd=$_POST['pwd'];
$conn=mysql_connect('localhost','root');
if(!$conn)
{
die('could not connect:'.mysql_errror());
}
mysql_select_db('project') or die(mysql_error());
$que="select * from login where uname='$name' and pwd='$pwd'";
$res=mysql_query($que,$conn) or die(mysql_error());
$res1=mysql_fetch_row($res);
if($res1)
{
 header('location:admin.php');
}
else
{
echo 'you entered username or password is incorrect';
}
mysql_close($conn);
?>
</body>
</html>