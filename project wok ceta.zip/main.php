<html>
<head>
<style>
body, html {
  height: 100%;
  margin: 0;
  font: 400 15px/1.8 "Lato", sans-serif;

}
.h1{
   font-family:elephant;}
.m{
    font-family:latin;
    
}
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 16px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    cursor: pointer;
}
.button2 {
    background-color:#008CBA; 
    color: black; 
    border: 2px solid #008CBA;
}

.button2:hover {
    background-color: #008CBA;
    color: #008CBA;
}

div.topdiv {
	background-image:url("sw.jpg");
	position:relative;
	top:0;
	height:17%;
	width:100%;
            font-size:16px;
          text-align:center;
        background-repeat: no-repeat;
        	}
div.bottomdiv {
	background-image:url("images1.jpg");
	position:relative;
	height:100%;
	width:100%;
	font-size:16px;
	text-align:center;
        background-repeat: no-repeat;
      background-size:cover;
 }
.s3
{
background-color:#ccffff;
}
</style>
</head>
<body text="#ff3385">
	<div class="topdiv"><br>
	<a target="_parent" href="main.php"><button class="button button2">HOME</button></a>
	<a target="_parent" href="adminlogin.php"><button class="button button2">ADMIN LOGIN</button></a>
	<a target="_parent" href="studentlogin.php"><button class="button button2">STUDENT LOGIN</button></a>
              </div>
	<div class="bottomdiv">
               <marquee behavior="alternate" class="h1"><h1 style="color:#ccffcc">VARDHAMAN COLLEGE OF ENGINEERING</h1></marquee><br>
                 <h1 class="m" style="color:#ffccff">CETA EVENT MANAGEMENT</h1>
     <img src="ii3.png" align="left">
     <img src="ii2.gif"  align="right"><br>
</div>

<center><h1 class="s3">NEWS AND EVENTS</h1><center>
<img src="pp1.jpg" >
<img src="ii6.jpg" align="left" >
<marquee behavior="alternate" direction="right">
<?php
$x=$_POST['t1'];
echo "$x";
?>
</marquee>
</body>
</html>