<html>
<style>
.s1
{
background-image:url("sw.jpg");
color:#ff1a75;
height:50px;
border-style:solid;
border-color:#80ffbf;
margin:10px;
padding:10px;
background-size:cover;
background-repeat:no-repeat;
}
.s2
{
background-image:url("index10.jpg");
height:520px;
border-style:solid;
border-color:#cc33ff;
margin:10px;
padding:10px;
background-repeat:no-repeat;
background-size:cover;
}
</style>
<body bgcolor="black">

<center><h1 class="s1">DELETEEVENT</h1></center>
<div class="s2">
<center>
<form method="post">
  <table style="color:purple;border-style:groove; height:150px;width:350px" background="backimage.jpg">

            <tr>

                <td style=" height:25px; font-family:'Copperplate Gothic Bold'">&nbsp;</td>

            </tr>

            <tr>

                <td style="color:red;background-color:aqua;height:15px"><center><h3>SELECT AN EVENT TO DELETE::</h3></center>
<select name="name" id="name" type="text">
  <option id="v1">debate</option>
  <option id="v2">ppt</option>
  <option id="v3">groupdiscussion</option>
  <option id="v4">jam</option>
  <option id="v5">cquiz</option>
<option id="v6">javaquiz</option>
<option id="v7">html</option>
<option id="v8">gd</option>
<option id="v9">pppresentation</option>
<option id="v10">python</option>
<option id="v11">coding</option>
</select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</tr>
<tr>

                <td style="height:25px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                           <input type="submit" value="DELETE" style="color:white;background-color:brown; height:30px" /></td>

            </tr>

 </form>   
</center>    
</div>
<?php
$eventname=$_POST['name'];
$conn = mysql_connect('localhost','root');
mysql_select_db('project');
$sql = "delete from debate where eventname = '".$eventname."'";
$res=mysql_query($sql,$conn) or die(mysql_error());
echo 'events are deleted successfully';
mysql_close($conn);
?>
</body>
</html>

