<html>
<head>
<style>
.s1
{
color: #ff0000;
height:50px;
border-style:solid;
border-color: #ffa31a;
border-width:thick;
margin:5px;
padding:5px;
background-repeat:no-repeat;
background-size:cover;
background-image:url(sw.jpg);
}
div {
    color:black;
    height:520px;
    border-width:thick;
   border-style:solid;
 border-color:#ffff66;
    padding: 10px;
    margin: 10px;
background-repeat:no-repeat;
background-size:cover;
background-image:url("index10.jpg");
}
</style>
</head>
<h1 class="s1"><center>POSTUPDATES</center></h1>
<body  bgcolor="black" text="black">
<center>
<div>
<form name="f1" method="post" action="main.php">
<textarea name="t1" rows="15" cols="40" style="background-color:#ccffff" >
</textarea><br>
<input type="submit" name="submit" value="submit"style="color:white;background-color:brown; height:30px" ></>
</form>
<?php
?>
</body>
</html>