<html>
<head>
<style>
body, html {
  height: 100%;
  margin: 0;
  font: 400 15px/1.8 "Lato", sans-serif;
}
form
{
background-color:"#008CBA";
}

.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 16px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    cursor: pointer;
}
.button2 {
    background-color: #008CBA; 
    color: black; 
    border: 2px solid #008CBA;
}

.button2:hover {
    background-color: #008CBA;
    color:#008CBA;
}
.h1{
   font-family:constantia;}
.m{
    font-family:garamond;
}
div.topdiv {
	background-image:url("sw.jpg");
	position:relative;
	top:0;
	height:17%;
	width:100%;
	font-size:16px;
	text-align:center;
        background-repeat: no-repeat;
        	}
div.bottomdiv {
               background-image:url("imagess.jpg");
	background-color:white;
	position:relative;
	height:100%;
	width:100%;
	font-size:16px;
	text-align:center;
        background-repeat: no-repeat;
      background-size:cover;
      
 }


</style>
</head>
<body color:"white">
	<div class="topdiv"><br>
	<a target="_parent" href="main.php"><button class="button button2">HOME</button></a>
	<a target="_parent" href="adminlogin.php"><button class="button button2">ADMIN  LOGIN</button></a>
	<a target="_parent" href="studentlogin.php"><button class="button button2">STUDENT LOGIN</button></a>
	</div>
	<div class="bottomdiv">
<h1 style="color:#ff80b3"><center>LOGIN FORM</center></h1>
<center>
<table align="center" border="yes">
<form name="f1" action="login.php" method="post">
<tr>
<th>ENTER USER NAME::<input type="text" name="name" size="30"></th>
</tr>
<tr>
<th>ENTER PASSWORD::<input  type="password" name="pwd" size="30"><br></th>
</tr>
<tr>
<th><input type="submit" value="login" name="b1">
</th>
</tr>
</form>
</table>
</center>
</div>
<?php
?>
</body>
</html>