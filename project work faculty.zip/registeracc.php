<!DOCTYPE html>
<html>
<head>
<link href="css/user_styles.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" src="js/user.js">
</script>
<style>
div.container {
    width: 100%;
    
}
a{color:black;}
header, footer {
    padding: 1em;
    color: white;
    background-color: black;
    clear: left;
    text-align: center;
}

nav {
    float: left;
    max-width: 150px;
    margin: 0;
    padding: 1em;
}

nav ul {
    list-style-type: none;
   
}
  a{
	  color:black:
  }
	  
page {
    margin-left: 120em;
    border-left: 0.5px solid gray;
    padding: 1em;
    overflow: hidden;
}
</style>
</head>
<body background="vote.jpeg">

<div class="container">

<header>
  <h1>Online Voting System</h1>
</header><br>
<nav>
 <h2><b>Student Registration</b></h2>
</nav>
<marquee><i>New polls are up and running. But they will not be up forever! Just Login and then go to Current Polls to vote for your favourite candidates. </i></marquee>

  <?php
require('connection.php');
//Process
if (isset($_POST['submit']))
{

$myFirstName = $_POST['firstname'] ; //prevents types of SQL injection
$myLastName =  $_POST['lastname']; //prevents types of SQL injection
$myEmail = $_POST['email'];
$myPassword = $_POST['password'];

//$newpass = md5($myPassword); //This will make your password encrypted into md5, a high security hash

$sql = mysql_query( "INSERT INTO tbMembers(first_name, last_name, email, password) VALUES ('$myFirstName','$myLastName', '$myEmail', '$myPassword')" )
        or die( mysql_error() );
echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";echo "<br>";echo "<br>";echo "<br>";
echo "<center>";
die( "<h3><b>You have registered for an account.</b></h3><br><br><h3><b>Go to <a href=\"studentlogin.php\">Login</a></b></h3>" );
echo "</center>";
}
echo "<page>";
echo "<center><h3>Register an account by filling in the needed information below:</h3></center><br><br>";
echo '<form action="registeracc.php" method="post" onsubmit="return registerValidate(this)">';
echo '<table align="center" bgcolor="#ccddff"><tr><td>';
echo "<tr><td>First Name:</td><td><input type='text' style='background-color:#999999; font-weight:bold;' name='firstname' maxlength='15' value=''></td></tr>";
echo "<tr><td>Last Name:</td><td><input type='text' style='background-color:#999999; font-weight:bold;' name='lastname' maxlength='15' value=''></td></tr>";
echo "<tr><td>Email Address:</td><td><input type='text' style='background-color:#999999; font-weight:bold;' name='email' maxlength='100' value=''></td></tr>";
echo "<tr><td>Password:</td><td><input type='password' style='background-color:#999999; font-weight:bold;' name='password' maxlength='15' value=''></td></tr>";
echo "<tr><td>Confirm Password:</td><td><input type='password' style='background-color:#999999; font-weight:bold;' name='ConfirmPassword' maxlength='15' value=''></td></tr>";
echo "<tr><td>&nbsp;</td><td><input type='submit' name='submit' value='Register Account'/></td></tr>";
echo "<tr><td colspan = '2'><p>Already have an account? <a href='index.php'><b>Login Here</b></a></td></tr>";
echo "</tr></td></table>";
echo "</form>";
echo "</page>";

?>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<footer>Copyright &copy;Online Voting System. All rights reserved.</footer>

</div>

</body>
</html>
