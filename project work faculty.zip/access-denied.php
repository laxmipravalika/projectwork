<!DOCTYPE html>
<html>
<head>
<style>
div.container {
    width: 100%;
    
}

header, footer {
    padding: 1em;
    color: white;
    background-color: black;
    clear: left;
    text-align: center;
}
a{color:black;}
nav {
    float: left;
    max-width: 150px;
    margin: 0;
    padding: 1em;
}

nav ul {
    list-style-type: none;
   
}
  
page {
    margin-left: 120em;
    border-left: 0.5px solid gray;
    padding: 1em;
    overflow: hidden;
}
</style>
</head>
<body background="vote.jpeg">

<div class="container">

<header>
   <h1>Online Voting System</h1>
</header>
  
<nav>
 <h2><b>Access Denied</b></h2>
</nav>

<page>
  <a href="student.php">Home</a> &nbsp;&nbsp; &nbsp;|  &nbsp; &nbsp; &nbsp;<a href="vote.php">Current Polls</a>  &nbsp; &nbsp; &nbsp;| &nbsp; &nbsp; &nbsp; <a href="manage-profile.php">Manage My Profile</a>
<br><br><br><br><br><br><br><br><br><p>You don't have access to this resource. <a href="login.php">Click here</a> to login first.</p>
</page>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<footer>Copyright &copy;Online Voting System. All rights reserved.</footer>

</div>

</body>
</html>
