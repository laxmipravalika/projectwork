<?php
require('connection.php');

session_start();
//If your session isn't valid, it returns you to the login screen for protection
//if(empty($_SESSION['admin_id'])){
// header("location:access-denied.php");
//}
?>
<html>
<head>
<script language="javascript" src="js/jquery-1.2.6.min.js"></script>
<script language="javascript" src="js/jquery.timers-1.0.0.js"></script>
<script type="text/javascript">

$(document).ready(function(){
   var j = jQuery.noConflict();
	j(document).ready(function()
	{
		j(".refresh").everyTime(1000,function(i){
			j.ajax({
			  url: "refresh.php",
			  cache: false,
			  success: function(html){
				j(".refresh").html(html);
			  }
			})
		})
		
	});
   j('.refresh').css({color:"green"});
});
</script>
<style>
div.container {
    width: 100%;
   
}

header, footer {
    padding: 1em;
    color: white;
    background-color: black;
    clear: left;
    text-align: center;
}

nav {
    float: left;
    max-width: 150px;
    margin: 0;
    padding: 1em;
}

nav ul {
    list-style-type: none;
   
}
  
page {
    margin-left: 120em;
    border-left: 0.5px solid gray;
    padding: 1em;
    overflow: hidden;
}
</style>
</head>
<body background="vote.jpeg">
</body>
</html>