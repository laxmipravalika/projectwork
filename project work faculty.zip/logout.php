<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<style>
div.container {
    width: 100%;
    
}

header, footer {
    padding: 1em;
    color: white;
    background-color: black;
    clear: left;
    text-align: center;
}

nav {
    float: left;
    max-width: 150px;
    margin: 0;
    padding: 1em;
}

nav ul {
    list-style-type: none;
   
}
  
page {
    margin-left: 120em;
    border-left: 0.5px solid gray;
    padding: 1em;
    overflow: hidden;
}
a{
color:black;
}	
</style>
</head>
<body background="thank.jpeg" width="100%">

<div class="container">

<header>
   <h1>Online Voting System</h1>
</header>
  
<nav>
 <h2><b>Logged Out Successfully</b></h2>
</nav>
<marquee><i>New polls are up and running. But they will not be up forever! Just Login and then go to Current Polls to vote for your favourite candidates. </i></marquee>
<page>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<center><h2><b>You have been successfully logged out</b></h2></center><br><br><br>
<h3><b>Return to <a href="index1.php">Home Page</a></b></h3>
</page>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<footer>Copyright &copy;Online Voting System. All rights reserved.</footer>

</div>
<?php
session_destroy();
?>
</body>
</html>
