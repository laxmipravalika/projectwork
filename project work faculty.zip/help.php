<!DOCTYPE html>
<html>
<head>
<link href="css/user_styles.css" rel="stylesheet" type="text/css"/>
<style>
div.container {
    width: 100%;
   
}

header, footer {
    padding: 1em;
    color: white;
    background-color: black;
    clear: left;
    text-align: center;
}
nav {
    float: left;
    max-width: 150px;
    margin: 0;
    padding: 1em;
}

nav ul {
    list-style-type: none;
   
}
 a
 {
	 color:black;
 }
page {
    margin-left: 120em;
    border-left: 0.5px solid gray;
    padding: 1em;
    overflow: hidden;
}
</style>
</head>
<body background="thank.jpeg">

<div class="container">

<header>
   <h1>Online Voting System</h1>
</header>
  <br>
<nav>
  <h2><b>Help?</b></h2>
</nav>
<marquee><i>New polls are up and running. But they will not be up forever! Just Login and then go to Current Polls to vote for your favourite candidates. </i></marquee><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<page>
 <center>This website contains the key facilities to vote for our favourite candidates.<br>
 Open any page and give the proper credentials and then you are on your job<br>
 Vote for your favourites and let the justice rule our nation<br>
 Let the best politician win<br></center>
 <br><br><br><br><br><br><br><br><br><br>The makers of this website are <i>Miss.Varsha , Miss.Pravalika and Mr.Abhilash.</i><br><br><br>
 Contact no:1234567890.
 <h3>Thank You for visiting</h3>
 <br><br><br><br><br><br><br><br><br>
 <h3><b>Return to <a href="index1.php">Home Page</a></b></h3>
  </page>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<footer>Copyright &copy;Online Voting System. All rights reserved.</footer>


</div>

</body>
</html>
