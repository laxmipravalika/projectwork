<!DOCTYPE html>
<html>
<head>
<link href="css/user_styles.css" rel="stylesheet" type="text/css"/>
<style>
div.container {
    width: 100%;
   
}

header, footer {
    padding: 1em;
    color: white;
    background-color: black;
    clear: left;
    text-align: center;
}
nav {
    float: left;
    max-width: 150px;
    margin: 0;
    padding: 1em;
}

nav ul {
    list-style-type: none;
   
}
 a
 {
	 color:black;
 }
page {
    margin-left: 120em;
    border-left: 0.5px solid gray;
    padding: 1em;
    overflow: hidden;
}
</style>
</head>
<body background="vote.jpeg">

<div class="container">

<header>
   <h1>Online Voting System</h1>
</header>
  <br>
<nav>
  <h2><b>Home</b></h2>
</nav>
<marquee><i>New polls are up and running. But they will not be up forever! Just Login and then go to Current Polls to vote for your favourite candidates. </i></marquee><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<page>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#ccddff">
<tr><td><center><b><a href="home.php">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="studentlogin.php">Student Login</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="admin.php">Administrator login</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="help.php">Contact Us</a></b></center></td></tr>
</table><br><br><br><br>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#ccddff">
<tr><td><center><b>
 The word "vote" means to choose from a list, to elect or to determine. The main goal of voting (in a scenario involving the citizens of a given country) is to come up with leaders of the people’s choice.
Most countries,India not an exception have problems when it comes to voting. Some of the problems involved include ridging votes during election, insecure or inaccessible polling stations, inadequate polling materials and also inexperienced personnel.
This online voting/polling system seeks to address the above issues. It should be noted that with this system in place, the users, citizens in this case shall be given ample time during the voting period. They shall also be trained on how to vote online before the election time.
</b></center></td></tr></table>
  </page>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<footer>Copyright &copy;Online Voting System. All rights reserved.</footer>


</div>

</body>
</html>
